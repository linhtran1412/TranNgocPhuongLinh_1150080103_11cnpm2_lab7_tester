import javax.swing.*;
import java.awt.*;

public class RegisterForm extends JFrame {

    public RegisterForm() {
        setTitle("Form Đăng Ký Tài Khoản – ShopVN.vn");
        setSize(500, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(13, 2, 10, 10));

        // Khởi tạo các trường nhập liệu
        add(new JLabel(" Họ và tên (*):"));
        JTextField txtHoTen = new JTextField();
        add(txtHoTen);

        add(new JLabel(" Tên đăng nhập (*):"));
        JTextField txtTenDangNhap = new JTextField();
        add(txtTenDangNhap);

        add(new JLabel(" Email (*):"));
        JTextField txtEmail = new JTextField();
        add(txtEmail);

        add(new JLabel(" Số điện thoại (*):"));
        JTextField txtSdt = new JTextField();
        add(txtSdt);

        add(new JLabel(" Mật khẩu (*):"));
        JPasswordField txtMatKhau = new JPasswordField();
        add(txtMatKhau);

        add(new JLabel(" Xác nhận mật khẩu (*):"));
        JPasswordField txtXacNhanMK = new JPasswordField();
        add(txtXacNhanMK);

        add(new JLabel(" Ngày sinh (dd/mm/yyyy):"));
        JTextField txtNgaySinh = new JTextField();
        add(txtNgaySinh);

        add(new JLabel(" Giới tính:"));
        JPanel genderPanel = new JPanel();
        JRadioButton rbNam = new JRadioButton("Nam");
        JRadioButton rbNu = new JRadioButton("Nữ");
        JRadioButton rbKhac = new JRadioButton("Không muốn tiết lộ");
        ButtonGroup bgGender = new ButtonGroup();
        bgGender.add(rbNam); bgGender.add(rbNu); bgGender.add(rbKhac);
        genderPanel.add(rbNam); genderPanel.add(rbNu); genderPanel.add(rbKhac);
        add(genderPanel);

        add(new JLabel(" Mã giới thiệu:"));
        JTextField txtMaGioiThieu = new JTextField();
        add(txtMaGioiThieu);

        add(new JLabel(""));
        JCheckBox chkDieuKhoan = new JCheckBox("Đồng ý Điều khoản (*)");
        add(chkDieuKhoan);

        JButton btnDangKy = new JButton("Đăng ký");
        add(btnDangKy);

        JButton btnDangNhap = new JButton("Đăng nhập");
        add(btnDangNhap);

        setVisible(true);
    }

    public static void main(String[] args) {
        new RegisterForm();
    }
}